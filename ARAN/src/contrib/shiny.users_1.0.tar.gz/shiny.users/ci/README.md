Dockerfile used for running tests on CircleCI.

1. Build with `docker build -t appsilon/shiny.users-build:3.4.1 .`
2. Publish with `docker push appsilon/shiny.users-build:3.4.1` (adjust the version tag accordingly)
`
