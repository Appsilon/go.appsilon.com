options(SHINY_USERS_URL = "http://localhost:8080")

VALID_API_KEY <- "36735795-ebc8-4f22-81be-048ca1eef333"


random_str <- function() {
  do.call(paste0, as.list(sample(letters, 10)))
}

make_user <- function(username = random_str(),
                      password = random_str(),
                      roles = list()) {
  list(
    username = username,
    password = password,
    roles = roles
  )
}

make_role <- function(name = random_str(), actions = list()) {
  list(name = name, actions = actions)
}
