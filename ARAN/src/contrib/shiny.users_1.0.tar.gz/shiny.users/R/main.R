APP_KEY_LENGTH <- 36

app_key_problem_msg <- paste("You have to register your Shiny App",
                             "in Shiny.Users and initialise with",
                             "a proper APP KEY. If you haven't got one,",
                             "please send us an email at shiny.users@appsilon.com.")

#' shiny.users
#'
#' This creates users object allowing for authentication and authorization.
#'
#' @param APP_KEY character with app key
#' @param roles A list of roles. Each role is a named list with name (character)
#'   and actions (vector of characters).
#'
#' @export
#' @import shiny
#' @import httr
#' @import purrr
#' @import glue
initialize_users <- function(APP_KEY, roles = list()) {

  SHINY_USERS_URL <- getOption("SHINY_USERS_URL", "https://shinyusers.appsilon.com")

  signed_in_user <- shiny::reactiveVal()
  signed_in_role <- shiny::reactiveVal("Unauthorized")
  signed_in_token <- shiny::reactiveVal()
  sign_in_problem <- shiny::reactiveVal()

  if ( (typeof(APP_KEY) != "character") | (nchar(APP_KEY) != APP_KEY_LENGTH)) {
    warning(app_key_problem_msg)
    sign_in_problem(list(status = "failed", reason = app_key_problem_msg))
  }

  list(
    authenticate = function(username, password) {
      body <- list(
        APP_KEY = APP_KEY,
        USER_EMAIL = username,
        PASSWORD = password
      )
      request <- httr::POST(glue::glue("{SHINY_USERS_URL}/api/v1/user/login/"), body = body, encode = "json")
      response_status <- check_response_status(httr::status_code(request))
      if (!is.null(response_status)) {
        sign_in_problem(list(status = "failed", reason = response_status))
      }
      else {
        response <- httr::content(request)
        if (response$ROLE == "Authorized") {
          sign_in_problem(NULL)
          signed_in_user(username)
          signed_in_role(response$ROLE)
          signed_in_token(response$TOKEN)
        } else
          sign_in_problem(list(status = "failed", reason = response$ROLE))
      }
    },
    logout = function() {
      body <- list(
        APP_KEY = APP_KEY,
        TOKEN = signed_in_token()
      )
      request <- httr::POST(glue::glue("{SHINY_USERS_URL}/api/v1/user/logout/"), body = body, encode = "json")
      response_status <- check_response_status(httr::status_code(request))
      if (!is.null(response_status)) {
        sign_in_problem(list(status = "failed", reason = response_status))
      }
      else {
        response <- httr::content(request)
        if (response$STATUS == "OK") {
          signed_in_user(NULL)
        } else
          sign_in_problem(list(status = "failed", reason = response$STATUS))
      }
    },
    is_authorized = function(action) {
      actions <- c(purrr::map(purrr::keep(roles, ~ .$name == signed_in_role()), ~ .$actions))
      (action %in% unlist(actions))
    },
    reset_password = function(username) {
      body <- list(
        APP_KEY = APP_KEY,
        USER_EMAIL = username
      )
      request <- httr::POST(glue::glue("{SHINY_USERS_URL}/api/v1/user/reset-password/"), body = body, encode = "json")
      response_status <- check_response_status(httr::status_code(request))
      if (is.null(response_status)) {
        response <- httr::content(request)
        return(response$STATUS)
      } else {
        sign_in_problem(list(status = "failed", reason = response_status))
      }
    },
    user = signed_in_user,
    sign_in_problem = sign_in_problem
  )
}

#' Checks response status
#'
#' @param response_code numeric with response code
#'
#' @return character with problem description or NULL in case of no problems
check_response_status <- function(response_code) {
  if (response_code == 502 || response_code == 404) {
    return("Problem with a connection to the authentication server.")
  }
  if (response_code == 400 || response_code == 403) {
    return("Bad request.")
  }
  NULL
}
