context("reset_password")

source("./fixtures.R")

test_that("should return OK status when user exists in database", {
  # Given:
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = a_role
  )
  # Then:
  shiny::isolate({
    expect_equal(users$reset_password("test"), "OK")
  })
})

test_that("should return FAILED status when user doesn't exist in database", {
  # Given:
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = a_role
  )
  # Then:
  shiny::isolate({
    expect_equal(users$reset_password("abc"), "FAILED")
  })
})
