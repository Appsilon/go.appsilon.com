#' Login screen UI
#'
#' @param id shiny component id
#'
#' @return shiny uiOutput login screen
#' @export
login_screen_ui <- function(id) {
  ns <- shiny::NS(id)
  shiny::uiOutput(ns("login_screen"))
}

#' Bootstrap login form
#'
#' @param ns shiny namespace
#' @param problem list with problem message in reason field (\code{problem$reason})
#' @param username_value character with username value
#' @param sign_in_button_style character with style of the sign in button eg.
#' \code{"color: #fff;"}. If NULL, default style is used.
#' @param remind_pass_button_style character with style of the reset button.
#'
#' @return div with login screen
#' @export
bootstrap_login_form <- function(ns, problem, username_value = "",
                                 sign_in_button_style = NULL,
                                 remind_pass_button_style = NULL) {
  if (is.null(sign_in_button_style)) {
    sign_in_button_style <- "color: #fff; background-color: #00acd2;"
  }
  shiny::tagList(
    shiny::div(id = "shiny_users_login_form",
      if (!is.null(problem)) {
        shiny::div(class = "alert alert-danger", style = "margin-bottom: 20px", problem$reason)
      },
      shiny::textInput(ns("username"), "Username"),
      shiny::passwordInput(ns("password"), "Password"),
      shiny::actionButton(ns("sign_in"), "Sign in",
                          style = sign_in_button_style),
      if (!is.null(problem)) {
        shiny::actionButton(ns("remind"), "Remind me the password",
                            style = remind_pass_button_style)
      }
      ),
      shiny::tags$script(
        autoclick_signin(ns)
      )
  )
}

#' Semanitc error message
#'
#' @param problem list with problem message in reason field (\code{problem$reason})
#' @param whatfailed character with description what exactly failed, eg. Login, Logout
#'
#' @return uimessage from shiny.semantic
#' @export
#' @import shiny.semantic
error_message <- function(problem, whatfailed = "Login") {
  shiny.semantic::uimessage(paste(whatfailed, "failed"),
                            problem$reason,
                            type = "icon error",
                            icon = "warning")
}

#' Semantic login form
#'
#' @param ns shiny namespace
#' @param problem list with problem message in reason field (\code{problem$reason})
#' @param username_value character with username value
#'
#' @import shiny
#' @export
semantic_login_form <- function(ns, problem, username_value = "") {
  div <- shiny::div
  username_ui <- shiny::tags$input(type = "text", placeholder = "Username")
  password_ui <- shiny::tags$input(type = "password", placeholder = "Password")

  tagList(
    div(id = "shiny_users_login_form", class = "ui middle aligned center aligned grid",
      div(class = "column", style = "max-width: 450px;",
        div(class = "ui stacked segment",
          shiny::tags$h2(class = "ui center aligned header", "Log-in"),
          if (!is.null(problem)) {
            div(style = "text-align: left; margin-bottom: 20px", error_message(problem))
          },
          shiny::tags$form(class = "ui large form",
            div(class = "field",
              div(class = "ui left icon input",
                uiicon("user"),
                shiny_text_input(ns("username"), username_ui)
              )
            ),
            div(class = "field",
              div(class = "ui left icon input",
                uiicon("lock"),
                shiny_text_input(ns("password"), password_ui)
              )
            ),
            shiny::actionButton(ns("sign_in"), "Sign in",
                                class = "ui basic button")
          ),
          if (!is.null(problem)) {
            warning("A password reset is not implemented in a semantic version yet.")
            shiny::actionButton(ns("remind"),
                                "Remind me the password",
                                class = "ui basic button")
          }
        )
      )
    ),
    tags$script(
      autoclick_signin(ns)
    )
  )
}

#' Sign in when button pressed in password field
#'
#' Generates JS code that enables signing in
#'
#' @param ns namaespaces
#'
#' @return HTML object with JS code
#' @import shiny
autoclick_signin <- function(ns) {
  shiny::HTML(paste0('
        $("#', ns("password"), '").on("keyup keypress", function(e) {
          var keyCode = e.keyCode || e.which;
          if (keyCode === 13) {
            e.stopPropagation();
            e.preventDefault();
            $("#', ns("sign_in"), '").click();
            return false;
          }
        });
      '))
}

#' Standard logout form
#'
#' @param ns shiny namespace
#' @param problem list with problem message in reason field (\code{problem$reason})
#' @param user character with user name
#'
#' @import shiny
#' @export
standard_logout_form <- function(ns, user, problem) {
  div(
    if (!is.null(problem)) {
      shiny::div(class = "alert alert-danger", style = "margin-bottom: 20px", problem$reason)
    },
    span("Signed in: ", shiny::tags$b(user)),
    shiny::actionButton(ns("sign_out"), "Sign out")
  )
}

#' Makes reminder modal for lost password
#'
#' @param ns namespace
#'
#' @return modal dialog object
#' @import shiny
make_remind_modal <- function(ns) {
  shiny::modalDialog(
    shiny::textInput(ns("remind_username"), "Your username:"),
    footer = shiny::tagList(
      shiny::modalButton("Cancel"),
      shiny::actionButton(ns("remindsend"), "Remind")
    ), size = "s"
  )
}

#' Default login screen
#'
#' @param input shiny input
#' @param output shiny output
#' @param session shiny session
#' @param users users object
#' @param login_form shiny div with login form
#' @param logout_form shiny div with logout form
#'
#' @export
#'
#' @import shiny
login_screen <- function(input,
                         output,
                         session,
                         users,
                         login_form = bootstrap_login_form,
                         logout_form = standard_logout_form) {
  output$login_screen <- renderUI({
    if (is.null(users$user())) {
      login_form(session$ns, users$sign_in_problem(), input$username)
    } else {
      if (is.null(logout_form)) {
        NULL
      } else {
        logout_form(session$ns, users$user(), users$sign_in_problem())
      }
    }
  })

  # Remind password click
  observeEvent(input$remind, {
    showModal(make_remind_modal(session$ns))
  })

  delayed_remindsend_click <- shiny::debounce(reactive(input$remindsend), 600)
  observeEvent(delayed_remindsend_click(), {
    reset_status <- users$reset_password(input$remind_username)
    removeModal()
    if (!is.null(reset_status)) {
      if (reset_status == "FAILED") {
        showModal(modalDialog(
          span("Sorry, not such user found."),
          size = "s"
        ))
      } else {
        showModal(modalDialog(
          span("Thank you! Expect email with next steps soon."),
          size = "s"
        ))
      }
    }
  })

  # Sign in click
  delayed_sign_in_click <- shiny::debounce(reactive(input$sign_in), 600)

  shiny::observeEvent(delayed_sign_in_click(), {
    users$authenticate(input$username, input$password)
  })
  shiny::observeEvent(input$sign_out, users$logout())
}
