context("logout")

source("./fixtures.R")

test_that("should clear authorized user", {
  # Given:
  a_role <- make_role()
  valid_user <- make_user("test", "pass", roles = list(a_role$name))
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = roles
  )
  # When:
  shiny::isolate({
    users$authenticate(valid_user$username, valid_user$password)
    users$logout()
  })

  # Then:
  isolate({
    expect_null(users$user())
  })
})
