context("authenticate")

source("./fixtures.R")

test_that("should return warning when api key not correcy", {
  expect_warning(initialize_users("36735795"))
})

test_that("should create valid initialize object", {
  iusers <- initialize_users(VALID_API_KEY)
  expect_equal(names(iusers), c("authenticate", "logout", "is_authorized",
                                "reset_password", "user", "sign_in_problem"))
})

test_that("should authenticate valid user and password", {
  # Given:
  a_role <- make_role()
  valid_user <- make_user("test", "pass", roles = list(a_role$name))
  users  <- shiny.users::initialize_users(
              VALID_API_KEY,
              roles = a_role
            )
  # When:
  shiny::isolate({
    users$authenticate(valid_user$username, valid_user$password)
  })

  # Then:
  shiny::isolate({
    expect_null(users$sign_in_problem())
    expect_equal(users$user(), valid_user$username)
  })
})

test_that("should not authenticate non-existing user", {
  # Given:
  a_role <- make_role()
  no_user <- make_user("nouser", "pass", roles = list(a_role$name))
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = roles
  )
  # When:
  shiny::isolate({
    users$authenticate(no_user$username, no_user$password)
  })

  # Then:
  shiny::isolate({
    expect_equal(users$sign_in_problem()$status, "failed")
    expect_equal(users$sign_in_problem()$reason, "Unauthorized")
  })
})

test_that("should not authenticate valid user and wrong password", {
  # Given:
  a_role <- make_role()
  wrong_user <- make_user("test", "wrongpass", roles = list(a_role$name))
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = roles
  )
  # When:
  shiny::isolate({
    users$authenticate(wrong_user$username, wrong_user$password)
  })

  # Then:
  shiny::isolate({
    expect_equal(users$sign_in_problem()$status, "failed")
    expect_equal(users$sign_in_problem()$reason, "Unauthorized")
  })
})
