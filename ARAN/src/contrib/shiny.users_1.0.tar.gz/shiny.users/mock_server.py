import json

from klein import Klein

class ItemStore(object):
    app = Klein()

    @app.route('/api/v1/user/login/', methods=['POST'])
    def login(self, request):
        request.setHeader('Content-Type', 'application/json')
        body = json.loads(request.content.read())
        print(body)
        if (body['USER_EMAIL'] == "test" and body['PASSWORD'] == "pass"):
            return json.dumps({'ROLE': 'Authorized', 'TOKEN': "rand0mToken"})
        else:
            return json.dumps({'ROLE': 'Unauthorized'})

    @app.route('/api/v1/user/logout/', methods=['POST'])
    def logout(self, request):
        request.setHeader('Content-Type', 'application/json')
        body = json.loads(request.content.read())
        print(body)
        return json.dumps({'STATUS': 'OK'})

    @app.route('/api/v1/user/reset-password/', methods=['POST'])
    def reset(self, request):
        request.setHeader('Content-Type', 'application/json')
        body = json.loads(request.content.read())
        print(body)
        if body['USER_EMAIL'] == "test":
            return json.dumps({'STATUS': 'OK'})
        else:
            return json.dumps({'STATUS': 'FAILED'})

if __name__ == '__main__':
    store = ItemStore()
    store.app.run('localhost', 8080)
