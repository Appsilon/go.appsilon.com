library(shiny)
library(shiny.users)
library(shiny.semantic)
library(tibble)

SHINY.USERS.APP_KEY <- "a2a2a2a2-a2a2-a2a2-a2a2-a2a2a2a2a2a2" # get your shiny.users key from the web service

ui <- shinyUI(semanticPage(
  div(class = "container",
    style = "padding: 4em",
    login_screen_ui("login_screen"),
    uiOutput("authorized_content")
  )
))

server <- shinyServer(function(input, output) {
  users <- initialize_users(SHINY.USERS.APP_KEY)

  callModule(login_screen, "login_screen", users, form_style = "semantic")

  output$authorized_content <- renderUI({
    if (!is.null(users$user())) {
      tagList(
        shiny::numericInput("secret_input", "Input secret number", 0),
        uiOutput("secret_output")
      )
    }
  })
  output$secret_output <- renderUI({
    span(as.numeric(input$secret_input) * 2)
  })
})

shinyApp(ui, server)
