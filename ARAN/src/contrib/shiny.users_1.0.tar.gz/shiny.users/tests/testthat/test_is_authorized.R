context("is_authorized")

source("./fixtures.R")

test_that("should block unauthorized", {
  # Given:
  an_action <- "admin"
  a_role <- make_role(actions = list(an_action))
  valid_user <- make_user("test", "pass", roles = list(a_role$name))
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = list(a_role)
  )

  # When:
  shiny::isolate({
    users$authenticate(valid_user$username, valid_user$password)
  })

  # Then:
  shiny::isolate({
    expect_false(users$is_authorized("admin"))
  })
})

test_that("should not block authorized", {
  # Given:
  an_action <- "admin"
  a_role <- make_role(name = "Authorized", actions = list(an_action))
  valid_user <- make_user("test", "pass", roles = list(a_role$name))
  users  <- shiny.users::initialize_users(
    VALID_API_KEY,
    roles = list(a_role)
  )

  # When:
  shiny::isolate({
    users$authenticate(valid_user$username, valid_user$password)
  })

  # Then:
  shiny::isolate({
    expect_true(users$is_authorized("admin"))
  })
})
