library(testthat)
library(shiny.users)

test_check("shiny.users")
